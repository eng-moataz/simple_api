configuration = {
    "env": "dev"
}